package com.example.project3;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;


public class SMSPermissionsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sms_activity);
        Button smsYes = findViewById(R.id.ButtonSmsYes);
        Button smsNo = findViewById(R.id.ButtonSmsNo);
    }
}
