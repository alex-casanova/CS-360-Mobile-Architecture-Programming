package com.example.project3;

import static java.lang.Integer.parseInt;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ItemDetailActivity extends AppCompatActivity {

    private EditText nameEditText, descriptionEditText, qtyEditText;
    private Item selectedItem;
    private Button deleteButton;


    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);
        initItems();
    }

    private void initItems() {
        nameEditText = findViewById(R.id.nameEditText);
        descriptionEditText = findViewById(R.id.descriptionEditText);
        qtyEditText = findViewById(R.id.qtyEditText);
        deleteButton = findViewById(R.id.deleteButton);
    }

    private void checkForEditNote(){
        Intent previousIntent = getIntent();
        int passedItemID = previousIntent.getIntExtra(Item.ITEM_EDIT_EXTRA, -1);
        selectedItem = Item.getItemForID(passedItemID);
        if (selectedItem != null){
            nameEditText.setText(selectedItem.getItemName());
            descriptionEditText.setText(selectedItem.getDescription());
            qtyEditText.setText(selectedItem.getQuantity());
        }
        else{
            deleteButton.setVisibility(View.INVISIBLE);
        }

    }

    public void saveItem(View view) {

        SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(this);

        String name = String.valueOf(nameEditText.getText());
        String description = String.valueOf(descriptionEditText.getText());
        String qty = String.valueOf(qtyEditText.getText());

        if(selectedItem == null){
            int id = Item.itemArrayList.size();
            Item newItem = new Item(id, name, description);
            Item.itemArrayList.add(newItem);
            sqLiteManager.addItemToDatabase(newItem);
        }
        else{
            selectedItem.setItemName(name);
            selectedItem.setDescription(description);
            sqLiteManager.updateItemInDB(selectedItem);
        }

        int id = Item.itemArrayList.size();
        Item newItem = new Item(id, name, description, parseInt(qty));
        Item.itemArrayList.add(newItem);
        sqLiteManager.addItemToDatabase((newItem));

        finish();
    }

    public void deleteItem(View view){
        selectedItem.setQuantity(0);
        SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(this);
        sqLiteManager.updateItemInDB(selectedItem);

    }


}
