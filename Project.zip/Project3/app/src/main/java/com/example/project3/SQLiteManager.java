package com.example.project3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class SQLiteManager extends SQLiteOpenHelper {
    private static SQLiteManager sqLiteManager;
    private static final String DATABASE_NAME = "ItemDB";
    private static final String DATABASE_VERSION = "1";
    private static final String TABLE_NAME = "Item";
    private static final String COUNTER = "Counter";


    private static final String ID_FIELD = "id";
    private static final String NAME_FIELD = "name";
    private static final String DESCRIPTION_FIELD= "description";
    private static final String QUANTITY_FIELD = "quantity";

    public SQLiteManager(Context context) {
        super(context, DATABASE_NAME, null, Integer.parseInt(DATABASE_VERSION));
    }

    public static SQLiteManager instanceOfDatabase(Context context){
        if (sqLiteManager == null) {
            sqLiteManager = new SQLiteManager(context);
        }
        return sqLiteManager;
    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        StringBuilder sql;
        sql = new StringBuilder()
                .append("CREATE TABLE ")
                .append(TABLE_NAME)
                .append("(")
                .append(COUNTER)
                .append(" INTEGER PRIMARY KEY AUTOINCREMENT, ")
                .append(ID_FIELD)
                .append(" INT, ")
                .append(NAME_FIELD)
                .append(" TEXT, ")
                .append(DESCRIPTION_FIELD)
                .append(" TEXT, ")
                .append(QUANTITY_FIELD)
                .append(" INT)");

        sqLiteDatabase.execSQL((sql.toString()));
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
    }

    public void addItemToDatabase(Item item){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(ID_FIELD, item.getId());
        contentValues.put(NAME_FIELD, item.getItemName());
        contentValues.put(DESCRIPTION_FIELD, item.getDescription());
        contentValues.put(QUANTITY_FIELD, item.getQuantity());
        
        sqLiteDatabase.insert(TABLE_NAME, null, contentValues);
    }

    public void populateItemListArray(){
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();

        try(Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM " + TABLE_NAME, null))
        {
            if (result.getCount() != 0)
            {
                while (result.moveToNext())
                {
                    int id = result.getInt(1);
                    String name = result.getString(2);
                    String description = result.getString(3);
                    int qty = result.getInt(4);
                }
            }
        }
    }
    public void updateItemInDB(Item item){

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(ID_FIELD, item.getId());
        contentValues.put(NAME_FIELD, item.getItemName());
        contentValues.put(DESCRIPTION_FIELD, item.getDescription());
        contentValues.put(QUANTITY_FIELD, item.getQuantity());

        sqLiteDatabase.update(TABLE_NAME, contentValues, ID_FIELD + " =? ", new String[]{String.valueOf(item.getId())});

    }

}
