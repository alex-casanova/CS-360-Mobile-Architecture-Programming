package com.example.project3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {
    private ListView itemListView;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initListView();
        loadFromDB();
        setItemAdapter();
        setOnClickListener();
    }

    private void setItemAdapter() {
        ItemAdapter itemAdapter = new ItemAdapter(getApplicationContext(), Item.itemArrayList);
        itemListView.setAdapter(itemAdapter);
    }

    private void loadFromDB(){
        SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(this);
        sqLiteManager.populateItemListArray();
    }
    private void initListView() {
        itemListView = findViewById(R.id.itemListView);
    }

    public void newItem(View view){
        Intent newItemIntent = new Intent(this, ItemDetailActivity.class);
        startActivity(newItemIntent);

    }

    private void setOnClickListener(){
        itemListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Item selectedItem = (Item) itemListView.getItemAtPosition(position);
                Intent editItemIntent = new Intent(getApplicationContext(), ItemDetailActivity.class);
                editItemIntent.putExtra(Item.ITEM_EDIT_EXTRA, selectedItem.getId());
                startActivity(editItemIntent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
    }
}
