package com.example.project3;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    EditText username, password;
    Button button_login, button_register;
    DBUsers DBUsers;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        button_login = (Button) findViewById(R.id.button_login);
        button_register = (Button) findViewById(R.id.button_register);
        DBUsers = new DBUsers(this);

        button_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String user = username.getText().toString();
                String pass = password.getText().toString();

                if (user.equals("") || pass.equals(""))
                    Toast.makeText(LoginActivity.this, "Please enter all the fields", Toast.LENGTH_SHORT).show();
                else {
                    Boolean checkuserpass = DBUsers.checkusernamepassword(user, pass);
                    Intent intent = null;
                    if (checkuserpass == true) {
                        Toast.makeText(LoginActivity.this, "Sign in successful", Toast.LENGTH_SHORT).show();
                        //TODO: SET SMS PERMISSIONS
                        if(true) {
                            intent = new Intent(getApplicationContext(), MainActivity.class);
                        }
                        else {
                            intent = new Intent(getApplicationContext(), SMSPermissionsActivity.class);
                        }
                        startActivity(intent);
                    } else
                        Toast.makeText(LoginActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });

        button_register.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {

               String user = username.getText().toString();
               String pass = password.getText().toString();

               if (user.equals("") || pass.equals(""))
                   Toast.makeText(LoginActivity.this, "Please enter all the fields", Toast.LENGTH_SHORT).show();
               else {
                   Boolean checkusername = DBUsers.checkusername(user);
                   if (checkusername == true) {
                       Toast.makeText(LoginActivity.this, "Account already exists!", Toast.LENGTH_SHORT).show();
                   } else {
                       Boolean register = DBUsers.insertData(user, pass);
                       if (register) {
                           Toast.makeText(LoginActivity.this, "Account created!", Toast.LENGTH_SHORT).show();
                       } else {
                           Toast.makeText(LoginActivity.this, "Registration FAILED!", Toast.LENGTH_SHORT).show();
                       }
                   }
               }
           }
       });
    }}