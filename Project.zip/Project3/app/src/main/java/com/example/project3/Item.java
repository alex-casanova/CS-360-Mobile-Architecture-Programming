package com.example.project3;

import java.util.ArrayList;

public class Item {

    public static String ITEM_EDIT_EXTRA = "itemEdit";

    public static ArrayList<Item> itemArrayList = new ArrayList<>();
    private int id;
    private String itemName;
    private String description;
    private int quantity;


    //Constructor with quantity
    public Item(int id, String itemName, String description, int quantity) {
        this.id = id;
        this.itemName = itemName;
        this.description = description;
        this.quantity = quantity;
    }

    //Constructor with no quantity - Sets Quantity to 0
    public Item(int id, String itemName, String description) {
        this.id = id;
        this.itemName = itemName;
        this.description = description;
        this.quantity = 0;
    }

    public static Item getItemForID(int passedItemID) {
        for (Item item : itemArrayList){
            if (item.getId() == passedItemID){
                return item;
            }
        }
        return null;
    }


    //Functions - Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
